const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

toggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", open);
});

document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

const dateInput = document.querySelector('input[name="date"]');
if (dateInput) {
  const today = new Date();
  const local = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
    .toISOString().split("T")[0];
  dateInput.min = local;
}

const form = document.getElementById("booking-form");
const toast = document.getElementById("toast");

form?.addEventListener("submit", (event) => {
  event.preventDefault();

  const data = new FormData(form);
  const name = data.get("name");
  const email = data.get("email");
  const date = data.get("date");
  const guests = data.get("guests");
  const eventType = data.get("event");
  const message = data.get("message");

  const subject = encodeURIComponent(`Boekingsaanvraag Sweet Wheels - ${eventType}`);
  const body = encodeURIComponent(
`Hallo Sweet Wheels,

Ik wil graag informeren naar een boeking.

Naam: ${name}
E-mail: ${email}
Datum: ${date}
Aantal gasten: ${guests}
Type event: ${eventType}

Extra informatie:
${message || "Geen extra informatie."}

Alvast bedankt!`
  );

  window.location.href = `mailto:info@sweetwheels.be?subject=${subject}&body=${body}`;

  toast.textContent = "Je mailprogramma wordt geopend…";
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 4000);
});
