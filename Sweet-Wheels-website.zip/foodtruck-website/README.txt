SWEET WHEELS - WEBSITE
=======================

BESTANDEN
---------
index.html  = inhoud van de website
style.css   = design, kleuren, responsive layout
script.js   = menu, datumcontrole en contactformulier

OPENEN IN VS CODE
-----------------
1. Pak de ZIP uit.
2. Open de map "foodtruck-website" in VS Code.
3. Installeer in VS Code de extensie "Live Server".
4. Rechtermuisknop op index.html.
5. Kies "Open with Live Server".

BELANGRIJK
----------
De website is volledig statisch en werkt meteen.
Het contactformulier opent momenteel het mailprogramma van de bezoeker.
Pas in index.html het volgende aan naar je echte gegevens:

info@sweetwheels.be
+32 4XX XX XX XX
Instagram / Facebook links

Ook de prijzen en teksten kun je rechtstreeks in index.html aanpassen.

ONLINE ZETTEN
------------
Je kunt deze website later gratis hosten met bijvoorbeeld GitHub Pages,
Netlify of Cloudflare Pages. Een eigen domeinnaam kan daar bovenop.
